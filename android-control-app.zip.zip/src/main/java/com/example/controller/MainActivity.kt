package com.example.controller // <-- MAKE SURE THIS MATCHES YOUR PROJECT!

import android.Manifest
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var btnConnect: Button
    private lateinit var btnGripper: Button // NEW
    private lateinit var webView3D: WebView

    private var isConnected = false
    private var isGripperOpen = true // Track gripper state
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    private val MY_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        btnConnect = findViewById(R.id.btnConnect)
        btnGripper = findViewById(R.id.btnGripper) // NEW
        webView3D = findViewById(R.id.webView3D)

        checkPermissions()
        setupButtons()
        setupWebView()
    }

    private fun setupButtons() {
        // Connect Button Logic
        btnConnect.setOnClickListener {
            if (!isConnected) showPairedDevicesDialog() else disconnectFromHC05()
        }

        // Gripper Button Logic (NEW)
        btnGripper.setOnClickListener {
            if (!isConnected) {
                Toast.makeText(this, "Connect to HC-05 first!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (isGripperOpen) {
                // Currently Open -> Send 'Q' to Close
                sendCommand("Q")
                btnGripper.text = "GRIPPER: CLOSE"
                isGripperOpen = false
            } else {
                // Currently Closed -> Send 'q' to Open
                sendCommand("q")
                btnGripper.text = "GRIPPER: OPEN"
                isGripperOpen = true
            }
        }
    }

    private fun setupWebView() {
        webView3D.settings.javaScriptEnabled = true
        webView3D.settings.domStorageEnabled = true
        webView3D.settings.allowFileAccess = true
        webView3D.settings.allowContentAccess = true
        webView3D.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView3D.webViewClient = WebViewClient()
        webView3D.webChromeClient = WebChromeClient()

        webView3D.addJavascriptInterface(WebAppInterface(), "Android")
        webView3D.loadUrl("file:///android_asset/index.html")
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun sendArmCommand(base: Int, j2: Int, j1: Int, wrist: Int, gripper: Int) {
            val command = "A,$base,$j2,$j1,$wrist,$gripper"
            sendCommand(command)
        }

        @JavascriptInterface
        fun sendCarCommand(command: String) {
            sendCommand(command)
        }
    }

    private fun showPairedDevicesDialog() {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            Toast.makeText(this, "Please enable Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        val pairedDevices = bluetoothAdapter?.bondedDevices
        val deviceList = mutableListOf<String>()
        val deviceMap = mutableMapOf<String, BluetoothDevice>()

        if (pairedDevices != null && pairedDevices.isNotEmpty()) {
            for (device in pairedDevices) {
                val deviceName = device.name ?: "Unknown"
                deviceList.add("$deviceName (${device.address})")
                deviceMap[deviceName] = device
            }
            AlertDialog.Builder(this)
                .setTitle("Select Bluetooth Device")
                .setItems(deviceList.toTypedArray()) { dialog, which ->
                    val selectedName = deviceList[which].split(" (")[0]
                    connectToDevice(deviceMap[selectedName]!!)
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            Toast.makeText(this, "No paired devices found.", Toast.LENGTH_LONG).show()
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        btnConnect.text = "Connecting..."
        btnConnect.isEnabled = false
        Thread {
            try {
                bluetoothSocket = device.createRfcommSocketToServiceRecord(MY_UUID)
                bluetoothSocket?.connect()
                outputStream = bluetoothSocket?.outputStream
                runOnUiThread {
                    isConnected = true
                    btnConnect.text = "DISCONNECT"
                    btnConnect.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.holo_green_light)
                    btnConnect.isEnabled = true
                    Toast.makeText(this, "Connected!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    btnConnect.text = "CONNECT HC-05"
                    btnConnect.isEnabled = true
                    Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun disconnectFromHC05() {
        try {
            outputStream?.close()
            bluetoothSocket?.close()
            isConnected = false
            btnConnect.text = "CONNECT HC-05"
            btnConnect.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.holo_blue_light)
        } catch (e: Exception) {}
    }

    private fun sendCommand(command: String) {
        if (!isConnected) {
            runOnUiThread { Toast.makeText(this, "Not connected!", Toast.LENGTH_SHORT).show() }
            return
        }
        Thread {
            try {
                outputStream?.write((command + "\n").toByteArray())
                outputStream?.flush()
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Send failed", Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    private fun checkPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN, Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }
}